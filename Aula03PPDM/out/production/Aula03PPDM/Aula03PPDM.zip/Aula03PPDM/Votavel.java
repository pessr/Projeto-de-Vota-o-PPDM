public interface Votavel {
    void adicionarVoto();
    int getVotos();
}
